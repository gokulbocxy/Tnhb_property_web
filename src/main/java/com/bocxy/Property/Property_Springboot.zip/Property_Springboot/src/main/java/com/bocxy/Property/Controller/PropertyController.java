package com.bocxy.Property.Controller;

import com.bocxy.Property.Entity.Allottee;
import com.bocxy.Property.Entity.SchemeData;
import com.bocxy.Property.Entity.UnitData;
import com.bocxy.Property.Repository.AllotteeRepo;
import com.bocxy.Property.Repository.SchemeDataRepo;
import com.bocxy.Property.Repository.UnitDataRepo;
import com.bocxy.Property.Service.PropertyService;
import com.bocxy.Property.common.ResponseDo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PropertyController {

    private final PropertyService propertyService;
    private final AllotteeRepo allotteeRepo;
    private final SchemeDataRepo schemeDataRepo;
    private final UnitDataRepo UnitDataRepo;
    private final ResponseDo responseDo;

    @Autowired
    public PropertyController(PropertyService propertyService, AllotteeRepo allotteeRepo,
                              SchemeDataRepo schemeDataRepo, UnitDataRepo unitDataRepo,
                              ResponseDo responseDo) {
        this.propertyService = propertyService;
        this.allotteeRepo = allotteeRepo;
        this.schemeDataRepo = schemeDataRepo;
        this.UnitDataRepo = unitDataRepo;
        this.responseDo = responseDo; // Autowire the ResponseDo object
    }

    //Schemes

    @PostMapping("/getAllSchemes")
    public ResponseDo getAllScheme(@RequestBody JSONObject json,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
        Long id = json.getAsNumber("id").longValue();
        try {
            List<SchemeData> allScheme = propertyService.getAllSchemeData();

            if (allScheme != null) {
                return responseDo.setSuccessResponse(allScheme);
            } else {
                return responseDo.setSuccessResponse("No Data Found", null);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred"); // Return a failure response in case of exception
        }
    }

    @PostMapping("/saveSchemeData")
    public ResponseDo saveSchemeData(@RequestBody List<SchemeData> schemeData) {
        try {
            List<SchemeData> savedSchemeData = propertyService.saveSchemeData(schemeData);

            if (savedSchemeData != null) {
                return responseDo.setSuccessResponse(savedSchemeData);
            } else {
                return responseDo.setFailureResponse("Failed to save SchemeData.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred while saving SchemeData.");
        }
    }

    @PostMapping("/getSchemeData")
    public ResponseDo getSchemeData(@RequestBody JSONObject json,
                                    HttpServletRequest request,
                                    HttpServletResponse response) {
        Long id = json.getAsNumber("id").longValue();
        try {
            SchemeData schemeData = propertyService.getSchemeData(id);

            if (schemeData != null) {
                return responseDo.setSuccessResponse(schemeData);
            } else {
                return responseDo.setFailureResponse("Division Office not found for the provided ID.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred"); // Return a failure response in case of exception
        }
    }

    //Allottee

    @PostMapping("/getAllAllottees")
    public ResponseDo getAllAllottees(@RequestBody JSONObject json,
                                      HttpServletRequest request,
                                      HttpServletResponse response) {
        Long id = json.getAsNumber("id").longValue();
        try {
            List<Allottee> allAllottees = propertyService.getAllAllottees();

            if (allAllottees != null) {
                return responseDo.setSuccessResponse(allAllottees);
            } else {
                return responseDo.setSuccessResponse("No Data Found", null);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred"); // Return a failure response in case of exception
        }
    }

    @PostMapping("/saveAllottees")
    public ResponseEntity<ResponseDo> saveAllottees(@RequestBody List<Allottee> allottees) {
        try {
            List<Allottee> savedAllottees = propertyService.saveAllottees(allottees);

            if (!savedAllottees.isEmpty()) {
                ResponseDo response = new ResponseDo();
                response.setSuccessResponse(true);
                response.setData(savedAllottees);
                return ResponseEntity.ok(response);
            } else {
                ResponseDo response = new ResponseDo();
                response.setSuccessResponse(false);
                response.setFailureResponse("Failed to save Allottees.");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            ResponseDo response = new ResponseDo();
            response.setSuccessResponse(false);
            response.setFailureResponse("An error occurred while saving Allottees.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

            //UnitData

    @PostMapping("/getAllUnitData")
    public ResponseDo getAllUnitData() {
        try {
            List<UnitData> allUnitDatas = propertyService.getAllUnitData();

            if (allUnitDatas != null) {
                return responseDo.setSuccessResponse(allUnitDatas);
            } else {
                return responseDo.setFailureResponse("No Data Found");
            }

        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred"); // Return a failure response in case of exception
        }
    }


    @PostMapping("/saveUnitData")
    public ResponseDo saveunitdata(@RequestBody List<UnitData> unitData) {
        try {
            List<UnitData> savedUnitData = propertyService.saveUnitData(unitData);

            if (!savedUnitData.isEmpty()) {
                return responseDo.setSuccessResponse(savedUnitData);
            } else {
                return responseDo.setFailureResponse("Failed to save Allottees.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred while saving Allottees.");
        }
    }


    @PostMapping("/getUnitData")
    public ResponseDo getUnitData(@RequestBody JSONObject json,
                                  HttpServletRequest request,
                                  HttpServletResponse response) {
        Long id = json.getAsNumber("id").longValue();
        try {
            UnitData headOffice = propertyService.getUnitData(id);

            if (headOffice != null) {
                return responseDo.setSuccessResponse(headOffice);
            } else {
                return responseDo.setFailureResponse("Head Office not found for the provided ID.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("An error occurred"); // Return a failure response in case of exception
        }
    }


    @PostMapping("/updateUnitData/{headOfficeId}")
    public ResponseDo updateUnitData(@PathVariable("headOfficeId") long headOfficeId, @RequestBody UnitData updatedUnitData) {
        try {

            updatedUnitData.setN_ID(headOfficeId);

            UnitData savedUnitData = propertyService.updateUnitData(updatedUnitData);
            return responseDo.setSuccessResponse(savedUnitData);
        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("Failed to update Head Office.");
        }
    }

    @PostMapping("/updateSchemeData/{divisionOfficeId}")
    public ResponseDo updateSchemeData(@PathVariable("divisionOfficeId") long divisionOfficeId, @RequestBody SchemeData updatedSchemeData) {
        try {
            updatedSchemeData.setN_ID(divisionOfficeId);

            SchemeData savedSchemeData = propertyService.updateSchemeData(updatedSchemeData);
            return responseDo.setSuccessResponse(savedSchemeData);
        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("Failed to update Division Office.");
        }
    }

    @PostMapping("/getUnitOfOneScheme")
    public ResponseDo getUnitOfScheme(@RequestBody JSONObject json,
                                      HttpServletRequest request,
                                      HttpServletResponse response) {
        Long nSchemeId = json.getAsNumber("id").longValue();
        try {
            List<UnitData> unitData = propertyService.getUnits(nSchemeId);
            return responseDo.setSuccessResponse(unitData);
        } catch (Exception e) {
            e.printStackTrace();
            return responseDo.setFailureResponse("Failed to list Unit Data");
        }

    }
}

//Todo
//File upload
//Delete Api from Melina-
// GET list by Scheme___id in the unit data table
//Edit Api in the unit data table
//Google sheet
//Param to count create api
//Get Allotte by ID