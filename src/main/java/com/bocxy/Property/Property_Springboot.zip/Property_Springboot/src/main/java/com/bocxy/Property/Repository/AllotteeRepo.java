package com.bocxy.Property.Repository;


import com.bocxy.Property.Entity.Allottee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AllotteeRepo extends JpaRepository<Allottee, Long> {

}