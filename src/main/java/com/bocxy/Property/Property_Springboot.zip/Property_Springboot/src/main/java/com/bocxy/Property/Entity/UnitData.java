package com.bocxy.Property.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "UnitData")
public class UnitData{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "N_ID")
    private Long N_ID;

    @Column(name = "V_TYPE_NAME")
    private String V_TYPE_NAME;

    @Column(name = "V_UNIT_NO")
    private String V_UNIT_NO;

    @Column(name = "V_BLOCK_NO")
    private String V_BLOCK_NO;

    @Column(name = "V_FLOOR_NO")
    private String V_FLOOR_NO;

    @Column(name = "N_UNIT_ID")
    private Long N_UNIT_ID;

    @Column(name = "N_SCHEME_ID")
    private Long N_SCHEME_ID;

    @Column(name = "V_GOVT_DISCREATION_QUOTA")
    private String V_GOVT_DISCREATION_QUOTA;

    @Column(name = "V_UNIT_ALLOTED_STATUS")
    private String V_UNIT_ALLOTED_STATUS;

    @Column(name = "V_ALLOTMENT_TYPE")
    private String V_ALLOTMENT_TYPE;

    @Column(name = "V_PLINT_AREA")
    private String V_PLINT_AREA;

    @Column(name = "V_UDS_AREA")
    private String V_UDS_AREA;

    @Column(name = "V_PLOT_AREA")
    private String V_PLOT_AREA;

    @Column(name = "V_CARPET_AREA")
    private String V_CARPET_AREA;

    @Column(name = "V_ROAD_FACING")
    private String V_ROAD_FACING;

    @Column(name = "V_CORNER_PLOT_STATUS")
    private String V_CORNER_PLOT_STATUS;

    @Column(name = "V_CATEGORY")
    private String V_CORNECATEGORYR_PLOT_STATUS;


    @Transient
    private String mode;

}
