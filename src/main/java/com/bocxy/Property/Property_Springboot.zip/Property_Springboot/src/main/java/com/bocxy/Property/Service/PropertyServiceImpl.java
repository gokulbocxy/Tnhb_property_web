package com.bocxy.Property.Service;
import com.bocxy.Property.Entity.Allottee;
import com.bocxy.Property.Entity.SchemeData;
import com.bocxy.Property.Entity.UnitData;
import com.bocxy.Property.Model.SaveModel;
import com.bocxy.Property.Repository.AllotteeRepo;
import com.bocxy.Property.Repository.SchemeDataRepo;
import com.bocxy.Property.Repository.UnitDataRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;


@Service
public class PropertyServiceImpl implements PropertyService {
    @Value("${upload.dir}")
    private String uploadDir;
    private final AllotteeRepo allotteeRepo;
    private final SchemeDataRepo schemeDataRepo;
    private final UnitDataRepo unitDataRepo;
    @Autowired
    public PropertyServiceImpl(AllotteeRepo allotteeRepo, SchemeDataRepo schemeDataRepo, UnitDataRepo unitDataRepo) {
        this.allotteeRepo = allotteeRepo;
        this.schemeDataRepo = schemeDataRepo;
        this.unitDataRepo = unitDataRepo;
    }

    @Override
    public List<Allottee> getAllAllottees() {
        return allotteeRepo.findAll();
    }

    @Override
    public Allottee getAllotteeById(Long id) {
        Optional<Allottee> optionalAllottee = allotteeRepo.findById(id);
        return optionalAllottee.orElse(null);
    }

//    @Override
//    public Allottee saveAllottee(Allottee circleOffice) {
//        return allotteeRepo.save(circleOffice);
//    }


    @Transactional
    @Override
    public List<Allottee> saveAllottees(List<Allottee> allottees) {
        List<Allottee> savedAllottees = new ArrayList<>();

        for (Allottee allottee : allottees) {
            if (allottee.getV_ALLOTTE_FILE()!= null) {
                String base64FileData = allottee.getV_ALLOTTE_FILE();
                byte[] decodedFileData = Base64.getDecoder().decode(base64FileData);
                String generatedFileName = allottee.getV_ALLOTTE_FILE_NAME();
                String uniqueFileName = UUID.randomUUID().toString() + "_" + generatedFileName;
                File dest = new File(uploadDir, uniqueFileName);

                try {
                    Files.write(dest.toPath(), decodedFileData);
                    allottee.setV_ALLOTTE_FILE_NAME(generatedFileName);
                    allottee.setV_ALLOTTE_FILE_PATH(dest.getAbsolutePath());
                } catch (IOException e) {

                }
            }
            if (allottee.getV_AADHAAR_FILE()!= null) {
                String base64FileData = allottee.getV_AADHAAR_FILE();
                byte[] decodedFileData = Base64.getDecoder().decode(base64FileData);
                String generatedFileName = allottee.getV_AADHAAR_FILE_NAME();
                String uniqueFileName = UUID.randomUUID().toString() + "_" + generatedFileName;
                File dest = new File(uploadDir, uniqueFileName);

                try {
                    Files.write(dest.toPath(), decodedFileData);
                    allottee.setV_AADHAAR_FILE_NAME(generatedFileName);
                    allottee.setV_AADHAAR_FILE_PATH(dest.getAbsolutePath());
                } catch (IOException e) {

                }
            }
            if (allottee.getV_OTHER_FILE()!= null) {
                String base64FileData = allottee.getV_OTHER_FILE();
                byte[] decodedFileData = Base64.getDecoder().decode(base64FileData);
                String generatedFileName = allottee.getV_OTHER_FILE_NAME();
                String uniqueFileName = UUID.randomUUID().toString() + "_" + generatedFileName;
                File dest = new File(uploadDir, uniqueFileName);

                try {
                    Files.write(dest.toPath(), decodedFileData);
                    allottee.setV_OTHER_FILE_NAME(generatedFileName);
                    allottee.setV_OTHER_FILE_PATH(dest.getAbsolutePath());
                } catch (IOException e) {

                }
            }


            Allottee savedAllottee = allotteeRepo.save(allottee);
            savedAllottees.add(savedAllottee);
        }

        return savedAllottees;
    }

    @Override
    public void deleteAllottee(Long id) {
        allotteeRepo.deleteById(id);
    }

    @Override
    public List<SchemeData>getAllSchemeData() {
        return schemeDataRepo.findAll();
    }

    @Override
    public SchemeData getSchemeData(Long id) {
        Optional<SchemeData> optionalSchemeData = schemeDataRepo.findById(id);
        return optionalSchemeData.orElse(null);
    }



    @Override
    public List<SchemeData> saveSchemeData(List<SchemeData> schemeData) {
        return schemeDataRepo.saveAll(schemeData);
    }
    @Override
    public List<UnitData> getAllUnitData() {
        return unitDataRepo.findAll();
    }

    @Override
    public UnitData getUnitData(Long id) {
        Optional<UnitData> optionalUnitData = unitDataRepo.findById(id);
        return optionalUnitData.orElse(null);
    }

    @Override

    public List<UnitData> saveUnitData(List<UnitData> unitData) {
        return unitDataRepo.saveAll(unitData);
    }

    @Override
    public UnitData updateUnitData(UnitData unitData) {
        return unitDataRepo.save(unitData);
    }

    @Override
    public SchemeData updateSchemeData(SchemeData divisionOffice) {
        return schemeDataRepo.save(divisionOffice);
    }
    public List<UnitData> getUnits(Long nSchemeId){
        return unitDataRepo.findByNSchemeId(nSchemeId);
    }



}
