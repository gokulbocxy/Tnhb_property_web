package com.bocxy.Property.Service;
import com.bocxy.Property.Entity.Allottee;
import com.bocxy.Property.Entity.SchemeData;
import com.bocxy.Property.Entity.UnitData;
import com.bocxy.Property.Model.SaveModel;

import java.util.List;

public interface PropertyService {




    List<Allottee> getAllAllottees();
    Allottee getAllotteeById(Long id);
//    Allottee saveAllottee(Allottee allottee);
List<Allottee> saveAllottees(List<Allottee> allottees);
    void deleteAllottee(Long id);
    List<SchemeData>getAllSchemeData();

    List<SchemeData> saveSchemeData(List<SchemeData> schemeData);
    SchemeData getSchemeData(Long id);
    List<UnitData>getAllUnitData();
//    public String saveUnitData(SaveModel unitData);
    UnitData getUnitData(Long id);
    UnitData updateUnitData(UnitData unitData);
    SchemeData updateSchemeData(SchemeData schemeData);
    List<UnitData> saveUnitData(List<UnitData> unitData);
    List<UnitData> getUnits(Long nSchemeId);


}
